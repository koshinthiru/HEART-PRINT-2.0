HEARTPRINT - put it on your phone screen
1. Upload this whole folder to a free host (Netlify, Cloudflare Pages or GitHub Pages). It must be https.
2. Open the site link on your phone.
3. iPhone (Safari): Share > Add to Home Screen. Android (Chrome): menu > Install app / Add to Home screen.
Cards you make stay on that phone. Tap Save & send to share a card through any app.
